package com.example.demo.controller;

import com.example.demo.model.Aluno;
import com.example.demo.repository.AlunoRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.ArrayList;

@RestController
public class AlunoController {
    private final AlunoRepository alunoRepository;

    public AlunoController(AlunoRepository alunoRepository) {
        this.alunoRepository = alunoRepository;
        alunoRepository.saveAll(List.of(
                new Aluno ("Iago", "052727150-04","iagovargas42@gmail.com")
        ));
    }
    @GetMapping("/alunos")
    Iterable<Aluno> getAlunos(){
        return alunoRepository.findAll();
    }
    //@GetMapping("/alunos/{id}")
    //Iterable<Aluno> getAlunos(@PathVariable int id){
        //return alunoRepository.findById(id);
   // }
}
