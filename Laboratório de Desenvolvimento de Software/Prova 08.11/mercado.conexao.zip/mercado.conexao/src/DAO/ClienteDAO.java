/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Cliente;
import mercado.conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class ClienteDAO {
    private Conexao conexao;
    private Connection conn;
    
    public ClienteDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir (Cliente cliente){
        String sql = "INSERT INTO Cliente (nome, CPF, ENDEREÇO, telefone) VALUES (?, ?,?,?)";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getCpf());
            stmt.setString(3, cliente.getEndereco());
            stmt.setString(4, cliente.getTelefone());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Cliente Cadastrado!");

        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar cliente: " + ex.getMessage());
    }
  }
    
    public List<Cliente> buscarProdutoPorNome(String nome) {
    String sql = "SELECT * FROM cliente WHERE nome LIKE ?";
    List<Cliente> clientes = new ArrayList<>();

    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, "%" + nome + "%"); 
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Cliente c = new Cliente();
            c.setId(rs.getInt("id"));
            c.setNome(rs.getString("nome"));
            c.setCpf(rs.getString("CPF"));
            c.setEndereco(rs.getString("ENDEREÇO"));
            c.setTelefone(rs.getString("telefone"));

            clientes.add(c);
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao buscar produto: " + ex.getMessage());
    }

    return clientes;
}
   public List<Cliente> getCliente(){
        String sql = "SELECT * FROM cliente";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery(); //Obtenho o retorno da consulta e retorno no resultset
            List<Cliente> lp = new ArrayList();
            
            while (rs.next()){
                Cliente p = new Cliente();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("CPF"));
                p.setEndereco(rs.getString("ENDEREÇO"));
                p.setTelefone(rs.getString("telefone"));
                lp.add(p);
            }
            return lp;
        }catch (SQLException ex){
            System.out.println ("Erro ao consultar pessoa: "+ex.getMessage());
            return null;
        }
    }
}
